setTimeout(()=>{
    window.location.href = 'https://www.4-72.com.co/'
}, 3000)